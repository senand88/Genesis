﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace GenesisAPI.Models
{
    public class Contact
    {

        //path of the csv
        private static string path = @"C:\\Data\\Contact.csv";

        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int TelephoneList { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public DateTime LastLoginOn { get; set; }
        public Guid Token { get; set; }

        /// <summary>
        /// user List..to be honest, it should be saved into a database
        /// </summary>
        private static List<Contact> InitialUserList
        {
            get
            {
                if (!userList.Any())
                    GetUserFromCsvFile();
                return userList;
            }
        }
        private static List<Contact> userList = new List<Contact>();

        private static void GetUserFromCsvFile()
        {
            //use csv as database 
            using (StreamReader rd = new StreamReader(path))
            {
                while (!rd.EndOfStream)
                {
                    List<string> l = rd.ReadLine().Split(',').ToList();

                    userList.Add(new Contact(Convert.ToInt32(l[0]),
                                        l[1],
                                        l[2],
                                        l[3],
                                        Convert.ToInt32(l[4]),
                                        Convert.ToDateTime(l[5]),
                                        Convert.ToDateTime(l[6]),
                                        Convert.ToDateTime(l[7]),
                                        Guid.Parse(l[8])));
                }
            }
        }

        private static void updateData(List<Contact> newList)
        {
            string text = "";
            foreach (Contact c in newList)
            {
                text += c.Id + "," +
                    c.Name + "," +
                    c.Email + "," +
                    c.Password + "," +
                    c.TelephoneList.ToString() + "," +
                    c.CreatedOn.ToString() + "," +
                    c.LastUpdatedOn.ToString() + "," +
                    c.LastLoginOn.ToString() + "," +
                    c.Token.ToString() + Environment.NewLine;
            }
            //use file instead of a Sql db
            File.WriteAllText(path, text);
            userList = newList;
        }

        internal static Contact SaveContact(Contact contact, out bool alreadyExist)
        {
            //check if already exists
            alreadyExist = InitialUserList.Any(e => e.Email.Equals(contact.Email));
            if (!alreadyExist)
            {
                contact.CreatedOn = DateTime.Now;
                contact.LastUpdatedOn = DateTime.Now;
                contact.LastLoginOn = DateTime.Now;
                contact.Token = Guid.NewGuid();
                //add contact to list
                InitialUserList.Add(contact);
                updateData(InitialUserList);
            }
            else
            {
                contact = null;
            }
            return contact;
        }

        public static Contact GetUserByID(int id, out string message)
        {
            //get user by id
            List<Contact> result = InitialUserList.Where(a => a.Id == id).ToList();
            if (result.Count == 1)
            {
                message = "OK";
                return result.Single();

            }
            else if (result.Count == 0)
            {
                message = "Invalid user id";
                return null;
            }
            else
            {
                message = "More than one user found";
                return null;
            }

        }
        public static Contact GetUserByEmailPassword(string email, string password, out bool pwdOK, out string message)
        {
            //get user by email and password
            List<Contact> user = InitialUserList.Where(a => a.Email.Equals(email)).ToList();
            pwdOK = false;
            Contact result;
            if (user.Count == 1)
            {
                message = "OK";
                pwdOK = user.Single().Password.Equals(password);
                result = user.Single();
                if (pwdOK)// update guid and lastLogin for that user and save into db
                {
                    List<Contact> newList = new List<Contact>();
                    foreach (var i in InitialUserList)
                    {
                        if (i == user.Single())
                        {
                            //update last login date and guid token
                            result = new Contact(i.Id, i.Name, i.Email, i.Password, i.TelephoneList, i.CreatedOn, i.LastLoginOn, DateTime.Now, Guid.NewGuid());
                            newList.Add(result);
                        }
                        else
                            newList.Add(i);
                    }
                    updateData(newList);

                }
                return result;

            }
            else if (user.Count == 0)
            {
                message = "Invalid user and / or password";
                return null;
            }
            else
            {
                message = "More than one user found";
                return null;
            }
        }

        //constructor
        public Contact(int id, string name, string email, string password, int telephoneList, DateTime createdOn, DateTime lastUpdatedOn, DateTime lastLoginOn, Guid token)
        {
            Id = id;
            Name = name;
            Email = email;
            Password = password;
            TelephoneList = telephoneList;
            CreatedOn = createdOn;
            LastUpdatedOn = lastUpdatedOn;
            LastLoginOn = lastLoginOn;
            Token = token;
        }

        //constructor
        public Contact() { }
    }

}