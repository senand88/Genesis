﻿using GenesisAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GenesisAPI.Controllers
{
    public class ContactController : ApiController
    {
        public HttpResponseMessage Post()
        {
            System.Net.Http.Headers.HttpRequestHeaders headers = this.Request.Headers;
            //check that header contains all the information
            if (!headers.Contains("currentUserToken") || !headers.Contains("currentID") || !headers.Contains("userIdToSearch"))
                return Request.CreateResponse<string>(System.Net.HttpStatusCode.Unauthorized, "Unauthorized");

            Guid currentUserToken = Guid.Parse( headers.GetValues("currentUserToken").First());
            int currentID = Convert.ToInt32(headers.GetValues("currentID").First());
            int userIdToSearch = Convert.ToInt32(headers.GetValues("userIdToSearch").First());

            if (currentUserToken == null)
                return Request.CreateResponse<string>(System.Net.HttpStatusCode.Unauthorized, "Unauthorized");
            string msg;
            Contact user = GenesisAPI.Models.Contact.GetUserByID(currentID, out msg);
            if (user.Token != currentUserToken)
            {
                //incorrect token
                return Request.CreateResponse<string>(System.Net.HttpStatusCode.Unauthorized, "Unauthorized");
            }
            else if (DateTime.Now.Subtract(user.LastLoginOn).TotalMinutes > 30)
            {
                //invalid session
                return Request.CreateResponse<string>(System.Net.HttpStatusCode.Unauthorized, "Invalid Session");
            }
            //ok. search the contact by id
            Contact usSearch = GenesisAPI.Models.Contact.GetUserByID(userIdToSearch, out msg);
            if (usSearch != null)
            {
                string contactString = string.Format("<li>USER SEARCHED</li> <li>Id = {0} </li><li>createdOn = {1} </li><li>lastUpdatedOn = {2} </li><li>lastLoginOn = {3} </li><li>token = {4} </li>",
                    usSearch.Id, usSearch.CreatedOn, usSearch.LastUpdatedOn, usSearch.LastLoginOn, usSearch.Token);
                return Request.CreateResponse<string>(System.Net.HttpStatusCode.OK, contactString);
            }
            return Request.CreateResponse<string>(System.Net.HttpStatusCode.Unauthorized, msg);
        }

    }
}
