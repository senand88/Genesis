﻿using GenesisAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GenesisAPI.Controllers
{
    public class SigninController : ApiController
    {
        public HttpResponseMessage Post(Contact contact)
        {
            string msg;
            bool pwdok;
            Contact us = GenesisAPI.Models.Contact.GetUserByEmailPassword(contact.Email, contact.Password,out pwdok, out msg);
            string contactString = msg;
            var response = Request.CreateResponse<string>(System.Net.HttpStatusCode.Unauthorized, contactString);
            if (us != null && pwdok)
            {
                response = Request.CreateResponse<Contact>(System.Net.HttpStatusCode.OK, us);
            }
            return response;
        }
    }
}
