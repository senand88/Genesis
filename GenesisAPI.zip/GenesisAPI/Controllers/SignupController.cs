﻿using GenesisAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GenesisAPI.Controllers
{
    public class SignupController : ApiController
    {

        public HttpResponseMessage Post(Contact contact)
        {
            bool alreadyExist;
            //create contact
            Contact created = Contact.SaveContact(contact, out alreadyExist);

            if (!alreadyExist)
            {
                string contactString = string.Format("<li>USER CREATED </li> <li>Id = {0} </li><li>createdOn = {1} </li><li>lastUpdatedOn = {2} </li><li>lastLoginOn = {3} </li><li>token = {4} </li>",
                    created.Id, created.CreatedOn, created.LastUpdatedOn, created.LastLoginOn, created.Token);
                return Request.CreateResponse<string>(System.Net.HttpStatusCode.Created, contactString) ;
            }
            return Request.CreateResponse<string>(System.Net.HttpStatusCode.Unauthorized, "Email already exists");
        }
    }
}
