Instead creating database with a simple table, I used a csv file, so to use 
the application you need to put the Contact.csv file that you find inside the zip in the path
C.\Data\Contact.csv
or you can change the path in the file Models\Contact.cs line 13
If you start the application you can test the functionalities using the web page, or you can use your preferred tool.

Andrea